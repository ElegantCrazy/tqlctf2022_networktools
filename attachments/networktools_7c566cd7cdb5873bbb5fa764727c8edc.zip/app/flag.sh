#flag.sh文件内容约定

#!/bin/bash
echo $1 > /flag
